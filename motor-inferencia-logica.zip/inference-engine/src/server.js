'use strict';

/**
 * Motor de Inferencia Lógica como Servicio
 * =========================================
 * Paradigmas:
 *  - Lógico:     Tau Prolog ejecuta consultas sobre base de conocimiento
 *  - Funcional:  Transformaciones puras (normalize, formatSolutions, pipe)
 *  - Asíncrono:  async/await y Promises para I/O y resolución de consultas
 */

const express  = require('express');
const tau      = require('tau-prolog');
const fs       = require('fs').promises;
const path     = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// ─────────────────────────────────────────────────────────────────────────────
// PROGRAMACIÓN FUNCIONAL — transformaciones puras sin efectos secundarios
// ─────────────────────────────────────────────────────────────────────────────

/** Normaliza la consulta: asegura punto final y elimina espacios extra */
const normalizeQuery = (raw) =>
  raw.trim().replace(/\.?\s*$/, '.');

/** Extrae el texto de una respuesta Tau Prolog como string limpio */
const termToString = (term) => {
  if (!term) return 'null';
  return term.toString();
};

/** Formatea una solución (objeto de sustituciones) como objeto plano */
const formatSolution = (session) => {
  const vars = {};
  // Recorre las variables de la sesión y las serializa funcionalmente
  session.thread.substitution
    ? Object.keys(session.thread.substitution).forEach(k => {
        vars[k] = termToString(session.thread.substitution[k]);
      })
    : null;
  return vars;
};

/** Composición funcional: aplica una lista de funciones en secuencia */
const pipe = (...fns) => (x) => fns.reduce((v, f) => f(v), x);

/** Pipeline de normalización de entrada */
const prepareQuery = pipe(
  (q) => (typeof q === 'string' ? q : String(q)),
  (q) => q.replace(/[\r\n]+/g, ' '),
  normalizeQuery
);

// ─────────────────────────────────────────────────────────────────────────────
// PROGRAMACIÓN ASÍNCRONA — Promesas y async/await
// ─────────────────────────────────────────────────────────────────────────────

/** Carga la base de conocimiento desde disco de forma asíncrona */
const loadKnowledgeBase = async () => {
  const kbPath = path.join(__dirname, '..', 'knowledge', 'base.pl');
  return fs.readFile(kbPath, 'utf-8');
};

/**
 * Crea una sesión Tau Prolog y carga el programa de forma asíncrona.
 * Devuelve una Promise que resuelve con la sesión lista.
 */
const createSession = (program) =>
  new Promise((resolve, reject) => {
    const session = tau.create();
    session.consult(program, {
      success: () => resolve(session),
      error:   (err) => reject(new Error(`Error cargando KB: ${JSON.stringify(err)}`))
    });
  });

/**
 * Ejecuta una consulta en la sesión y recoge TODAS las soluciones.
 * Asíncrono: usa Promise que acumula respuestas del motor lógico.
 */
const runQuery = (session, query, maxSolutions = 50) =>
  new Promise((resolve, reject) => {
    session.query(query, {
      success: () => {
        const solutions = [];

        const collectNext = () => {
          if (solutions.length >= maxSolutions) {
            return resolve({ solutions, truncated: true });
          }

          session.answer({
            success: (answer) => {
              // Programación funcional: transforma la respuesta a objeto plano
              const vars = {};
              if (answer && answer.links) {
                Object.entries(answer.links).forEach(([k, v]) => {
                  vars[k] = v ? v.toString() : 'null';
                });
              }
              solutions.push(
                Object.keys(vars).length > 0 ? vars : { result: 'true' }
              );
              collectNext();          // recursión asíncrona para siguiente solución
            },
            fail: () => {
              // No hay más soluciones — resolvemos con lo acumulado
              resolve({ solutions, truncated: false });
            },
            error: (err) => {
              reject(new Error(`Error en inferencia: ${JSON.stringify(err)}`));
            },
            limit: () => {
              resolve({ solutions, truncated: true });
            }
          });
        };

        collectNext();
      },
      error: (err) => reject(new Error(`Error parseando consulta: ${JSON.stringify(err)}`))
    });
  });

// ─────────────────────────────────────────────────────────────────────────────
// RUTAS HTTP — integración de los tres paradigmas
// ─────────────────────────────────────────────────────────────────────────────

/**
 * POST /query
 * Body: { "query": "<consulta Prolog>", "maxSolutions": <número opcional> }
 */
app.post('/query', async (req, res) => {
  const startTime = Date.now();

  try {
    const raw = req.body?.query;
    if (!raw) {
      return res.status(400).json({
        success: false,
        error: 'El campo "query" es requerido en el body JSON.'
      });
    }

    // Paradigma funcional: pipeline de normalización
    const query        = prepareQuery(raw);
    const maxSolutions = Number(req.body?.maxSolutions) || 50;

    // Paradigma asíncrono: carga de KB y creación de sesión en paralelo con await
    const program = await loadKnowledgeBase();
    const session = await createSession(program);

    // Paradigma lógico: inferencia mediante Tau Prolog
    const { solutions, truncated } = await runQuery(session, query, maxSolutions);

    const elapsed = Date.now() - startTime;

    return res.json({
      success:        true,
      query,
      solutionsCount: solutions.length,
      truncated,
      solutions,
      elapsedMs:      elapsed
    });

  } catch (err) {
    const elapsed = Date.now() - startTime;
    return res.status(500).json({
      success:   false,
      error:     err.message,
      elapsedMs: elapsed
    });
  }
});

/** GET /health — verificación de estado del servicio */
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'Motor de Inferencia Lógica', port: PORT });
});

/** GET /examples — lista de consultas de ejemplo */
app.get('/examples', (_req, res) => {
  res.json({
    examples: [
      { description: 'Penalización aplicable a contract1',    query: 'penalty_applicable(contract1).' },
      { description: 'Todos los contratos con penalización',  query: 'penalty_applicable(X).' },
      { description: 'Contratos exitosos',                    query: 'successful_contract(X).' },
      { description: 'Contratos en riesgo',                   query: 'at_risk_contract(X).' },
      { description: 'Clientes confiables',                   query: 'reliable_client(X).' },
      { description: 'Contratos de alto valor',               query: 'high_value_contract(X).' },
      { description: 'Contratos de alto riesgo',              query: 'high_risk_contract(X).' },
      { description: 'Renovación recomendada',                query: 'renewal_recommended(X).' },
      { description: 'Auditoría requerida',                   query: 'audit_required(X).' },
      { description: 'Contratos de largo plazo',              query: 'long_term_contract(X).' },
      { description: 'Resumen de contract3',                  query: 'contract_summary(contract3,C,T,D,V,P,S,H).' },
      { description: 'Todos los contratos (hechos)',          query: 'contract(X,Client,Type,D,V).' }
    ]
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// INICIO DEL SERVIDOR
// ─────────────────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n🧠  Motor de Inferencia Lógica escuchando en http://localhost:${PORT}`);
  console.log(`📖  Ejemplos de consultas: GET http://localhost:${PORT}/examples`);
  console.log(`❤️   Health check:          GET http://localhost:${PORT}/health\n`);
});

module.exports = app;
