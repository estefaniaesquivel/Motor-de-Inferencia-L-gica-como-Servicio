% ============================================================
%  Base de Conocimiento — Motor de Inferencia Lógica
%  Dominio: Gestión de Contratos y Sanciones
% ============================================================

% --- HECHOS: Contratos ---
contract(contract1, alice,   software_dev, 12, 50000).
contract(contract2, bob,     consulting,    6, 30000).
contract(contract3, charlie, maintenance,  24, 80000).
contract(contract4, diana,   software_dev,  3, 15000).
contract(contract5, eve,     consulting,   18, 60000).

% contract(ID, Client, Type, DurationMonths, Value)

% --- HECHOS: Estado de entrega ---
delivered_on_time(contract1, false).
delivered_on_time(contract2, true).
delivered_on_time(contract3, false).
delivered_on_time(contract4, false).
delivered_on_time(contract5, true).

% --- HECHOS: Calidad del trabajo ---
quality_approved(contract1, false).
quality_approved(contract2, true).
quality_approved(contract3, true).
quality_approved(contract4, false).
quality_approved(contract5, true).

% --- HECHOS: Pagos realizados ---
payment_completed(contract1, true).
payment_completed(contract2, true).
payment_completed(contract3, false).
payment_completed(contract4, true).
payment_completed(contract5, false).

% --- HECHOS: Clientes con historial positivo ---
good_client(bob).
good_client(eve).

% --- HECHOS: Tipos de contrato críticos ---
critical_type(software_dev).
critical_type(maintenance).

% ============================================================
%  REGLAS DE INFERENCIA
% ============================================================

% R1: Penalización aplicable si hay retraso Y calidad no aprobada
penalty_applicable(ContractID) :-
    contract(ContractID, _, _, _, _),
    delivered_on_time(ContractID, false),
    quality_approved(ContractID, false).

% R2: Contrato exitoso si fue entregado a tiempo Y calidad aprobada
successful_contract(ContractID) :-
    delivered_on_time(ContractID, true),
    quality_approved(ContractID, true).

% R3: Contrato en riesgo si no está pagado y tiene retraso
at_risk_contract(ContractID) :-
    contract(ContractID, _, _, _, _),
    payment_completed(ContractID, false),
    delivered_on_time(ContractID, false).

% R4: Cliente confiable si tiene historial positivo O su contrato fue exitoso
reliable_client(Client) :-
    good_client(Client).
reliable_client(Client) :-
    contract(ContractID, Client, _, _, _),
    successful_contract(ContractID).

% R5: Contrato de alto valor si supera 50000
high_value_contract(ContractID) :-
    contract(ContractID, _, _, _, Value),
    Value > 50000.

% R6: Contrato de alto riesgo si es tipo crítico, no pagado y con retraso
high_risk_contract(ContractID) :-
    contract(ContractID, _, Type, _, _),
    critical_type(Type),
    payment_completed(ContractID, false).

% R7: Renovación recomendada si el contrato fue exitoso y el cliente es confiable
renewal_recommended(ContractID) :-
    contract(ContractID, Client, _, _, _),
    successful_contract(ContractID),
    reliable_client(Client).

% R8: Auditoría requerida si hay penalización aplicable o contrato en riesgo
audit_required(ContractID) :-
    penalty_applicable(ContractID).
audit_required(ContractID) :-
    at_risk_contract(ContractID).

% R9: Contrato largo si dura más de 12 meses
long_term_contract(ContractID) :-
    contract(ContractID, _, _, Duration, _),
    Duration > 12.

% R10: Resumen completo de un contrato
contract_summary(ContractID, Client, Type, Duration, Value, Penalty, Success, HighValue) :-
    contract(ContractID, Client, Type, Duration, Value),
    ( penalty_applicable(ContractID) -> Penalty = yes ; Penalty = no ),
    ( successful_contract(ContractID) -> Success = yes ; Success = no ),
    ( high_value_contract(ContractID) -> HighValue = yes ; HighValue = no ).
