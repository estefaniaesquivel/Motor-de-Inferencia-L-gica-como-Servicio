#!/usr/bin/env node
/**
 * build.js — Genera ejecutables autónomos con pkg
 * Uso: node scripts/build.js
 */
const { execSync } = require('child_process');
const fs           = require('fs');
const path         = require('path');

const ROOT = path.join(__dirname, '..');

// Verificar que pkg esté instalado
try {
  execSync('pkg --version', { stdio: 'ignore' });
} catch {
  console.log('📦 Instalando pkg globalmente...');
  execSync('npm install -g pkg', { stdio: 'inherit' });
}

// Agregar configuración de pkg al package.json si no existe
const pkgJsonPath = path.join(ROOT, 'package.json');
const pkgJson = JSON.parse(fs.readFileSync(pkgJsonPath, 'utf-8'));

if (!pkgJson.pkg) {
  pkgJson.pkg = {
    assets: ['knowledge/**/*'],
    targets: ['node18-win-x64', 'node18-macos-x64', 'node18-linux-x64'],
    outputPath: 'dist'
  };
  fs.writeFileSync(pkgJsonPath, JSON.stringify(pkgJson, null, 2));
  console.log('✅ Configuración pkg agregada a package.json');
}

// Crear carpeta dist
const distDir = path.join(ROOT, 'dist');
if (!fs.existsSync(distDir)) fs.mkdirSync(distDir);

console.log('\n🔨 Compilando ejecutables...\n');

execSync(
  `pkg src/server.js --targets node18-win-x64,node18-macos-x64,node18-linux-x64 --output dist/inference-engine --assets "knowledge/**/*"`,
  { stdio: 'inherit', cwd: ROOT }
);

console.log('\n✅ Ejecutables generados en ./dist/:');
fs.readdirSync(distDir).forEach(f => console.log(`   ${f}`));
